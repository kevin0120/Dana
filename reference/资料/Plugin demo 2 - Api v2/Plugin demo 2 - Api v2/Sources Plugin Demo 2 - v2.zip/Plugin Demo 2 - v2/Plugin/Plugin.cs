﻿using System;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using Desoutter.ProcessControl.Plugin.v2.Interface;
using Desoutter.ProcessControl.Plugin.v2.Interface.AttributeParameter;
using Desoutter.ProcessControl.Plugin.v2.Interface.Model;
using Plugin.ViewModel;
using Plugin.View;
using GalaSoft.MvvmLight.CommandWpf;
using System.Collections.Generic;
using Desoutter.ProcessControl.Plugin.v2.Interface.Model.Production.Result;
using Desoutter.ProcessControl.Plugin.v2.Interface.Model.Production.Result.Step;
using System.Linq;

namespace Plugin
{
    [Plugin]
    public class Plugin : PluginBase
    {
        private MainViewModel _viewModel;
        private FrameworkElement _view;
        private TaskCompletionSource<StepResult> _taskCompletionSource;
        private CancellationTokenSource _tokenSource;

        public override FrameworkElement CreateControl()
        {
            if (_view != null) return _view;

            _view = new MainView();
            _viewModel = new MainViewModel
            {
                ValidateCommand = new RelayCommand(ValidatePluginStep)
            };

            _view.DataContext = _viewModel;

            return _view;
        }

        public override bool HasToCreateControl()
        {
            return true;
        }

        public override StepResult ExecuteStep(object parameters)
        {
            // fusion parameters
            var param = parameters as Parameters;
        
            _tokenSource = new CancellationTokenSource();
            _taskCompletionSource = new TaskCompletionSource<StepResult>();

            Application.Current.Dispatcher.Invoke(async () =>
            {
                _viewModel.Results.Clear();
                _viewModel.Steps.Clear();
                _viewModel.Users.Clear();

                // previous steps results
                var a = await InfinityService.Production.GetPreviousResultsAsync(new List<StepType>() { StepType.All });
                a.ForEach(delegate (PreviousResult pr)
                {
                    _viewModel.Results.Add(pr);
                });

                // gets steps info
                var steps = await InfinityService.Configuration.GetStepsAsync(new List<StepType>() { StepType.All });
                steps.ForEach(_viewModel.Steps.Add);

                // get logged users
                var users = await InfinityService.Production.GetLoggedUsersAsync();
                users.ForEach(_viewModel.Users.Add);
            });

            _taskCompletionSource.Task.Wait(_tokenSource.Token);
            return _taskCompletionSource.Task.Result;
        }

        private void ValidatePluginStep()
        {
            _taskCompletionSource.SetResult(new StepResult { Data = "OK", IsPassed = true });
        }

        public override void CycleStart()
        {
    
        }

        public override void StepEndedPrematurely()
        {
            _taskCompletionSource.SetResult(new StepResult { Data = "Cycle Skipped/Scrapped", IsPassed = false });
        }
    }
}
