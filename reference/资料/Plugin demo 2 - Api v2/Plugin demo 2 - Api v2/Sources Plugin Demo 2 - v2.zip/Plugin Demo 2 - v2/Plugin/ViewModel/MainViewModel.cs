﻿using System.Windows.Input;
using GalaSoft.MvvmLight;
using System.Collections.ObjectModel;
using Desoutter.ProcessControl.Plugin.v2.Interface.Model;
using Plugin.Model;
using Desoutter.ProcessControl.Plugin.v2.Interface.Model.Configuration.Step;
using Desoutter.ProcessControl.Plugin.v2.Interface.Model.Production.Result;
using Desoutter.ProcessControl.Plugin.v2.Interface.Model.User;

namespace Plugin.ViewModel
{
    public class MainViewModel : ViewModelBase
    {
        private string _cycleCounter;
        public string CycleCounter
        {
            get { return _cycleCounter; }
            set { Set(ref _cycleCounter, value); }
        }

        private ICommand _validateCommand;
        public ICommand ValidateCommand
        {
            get { return _validateCommand; }
            set { Set(ref _validateCommand, value); }
        }

        public ObservableCollection<PreviousResult> Results { get; set; } = new ObservableCollection<PreviousResult>();

        public ObservableCollection<Step> Steps { get; set; } = new ObservableCollection<Step>();

        public ObservableCollection<User> Users { get; set; } = new ObservableCollection<User>();
    }
}
