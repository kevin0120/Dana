﻿using System;
using System.Collections.ObjectModel;
using Desoutter.ProcessControl.Plugin.v2.Interface.Model.Configuration.Step;
using Desoutter.ProcessControl.Plugin.v2.Interface.Model.Production.Result;
using Desoutter.ProcessControl.Plugin.v2.Interface.Model.User;

namespace Plugin.ViewModel
{
    class MainViewModelDesignData
    {
        public string Param { get; set; } = "Previous result";
        public ObservableCollection<PreviousResult> Results { get; set; } = new ObservableCollection<PreviousResult>()
        {
        };

        public ObservableCollection<Step> Steps { get; set; } = new ObservableCollection<Step>()
        {
        };
        public ObservableCollection<User> Users { get; set; } = new ObservableCollection<User>()
        {
        };
    }
}
