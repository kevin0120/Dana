﻿using Desoutter.ProcessControl.Plugin.v2.Interface.AttributeParameter;

namespace Plugin
{
    [PluginParameters]
    public class Parameters
    {

    }
}
