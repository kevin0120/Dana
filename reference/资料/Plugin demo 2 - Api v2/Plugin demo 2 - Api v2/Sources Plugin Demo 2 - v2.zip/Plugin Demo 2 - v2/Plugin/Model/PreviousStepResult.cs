﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Desoutter.ProcessControl.Plugin.v2.Interface.Model;
using Desoutter.ProcessControl.Plugin.v2.Interface.Model.Production.Result;

namespace Plugin.Model
{
    class PreviousStepResult
    {
        /// <summary>
        /// Name of the step.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Type of the step
        /// </summary>
        public string Type { get; set; }

        /// <summary>
        /// Previous Result.
        /// </summary>
        public PreviousResult Result { get; set; }
    }
}
