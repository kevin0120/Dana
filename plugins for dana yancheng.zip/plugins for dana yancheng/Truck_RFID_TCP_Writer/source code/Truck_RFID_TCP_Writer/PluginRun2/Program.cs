﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Truck_RFID_TCP_Writer;

namespace PluginRun2
{
    class Program
    {
        static void Main(string[] args)
        {
            Plugin plug = new Plugin();
            plug.WriterTo("192.168.0.123", "3000","this is a very beautiful skyhhhhhhhhh!!");

            //plug.Writer("192.168.0.123", "3000", "Hello world!    ");
            Console.ReadKey();



        }
    }
}
