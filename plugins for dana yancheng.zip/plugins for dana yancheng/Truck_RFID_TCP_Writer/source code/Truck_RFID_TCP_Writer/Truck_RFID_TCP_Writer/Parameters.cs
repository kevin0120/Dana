﻿using Desoutter.ProcessControl.Plugin.v2.Interface.AttributeParameter;

namespace Truck_RFID_TCP_Writer
{
    [PluginParameters]
    class Parameters
    {
        [PluginParameter("IP", "ip address of rfid ")]
        public string IP { get; set; }

        [PluginParameter("Port", "port number of rfid")]
        public string Port { get; set; }

        [PluginParameter("ProNum_Bcode", "proNumber and Bcode string")]
        public string ProNum_Bcode { get; set; }


    }
}
