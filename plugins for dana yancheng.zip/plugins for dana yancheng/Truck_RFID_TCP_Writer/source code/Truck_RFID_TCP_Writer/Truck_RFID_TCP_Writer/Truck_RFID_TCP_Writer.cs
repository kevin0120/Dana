﻿using System;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows;
using Desoutter.ProcessControl.Plugin.v2.Interface;
using Desoutter.ProcessControl.Plugin.v2.Interface.AttributeParameter;
using Desoutter.ProcessControl.Plugin.v2.Interface.Model;

namespace Truck_RFID_TCP_Writer
{
    [Plugin]
    public class Plugin : PluginBase
    {
        bool listenStart = false;
        TcpClient client;
        NetworkStream sendStream;
        private static Thread _ComSend; //发送数据线程
        private static bool Sending = false;//正在发送数据状态字
        private SendStr sendStr = new SendStr(); //读rfid
        private SendStr sendStr2 = new SendStr(); //写rfid
        private struct SendStr
        {
            public byte[] SendData;
        }

        public override FrameworkElement CreateControl()
        {
            return null;
        }

        public override bool HasToCreateControl()
        {
            return false;
        }

        public override StepResult ExecuteStep(object parameters)
        {
            var param = parameters as Parameters;


            Connect(param.IP.Trim(), param.Port.Trim());
            // reader request
            byte[] cmdData = new byte[2];
            cmdData[0] = 0x70;
            cmdData[1] = 0x00;
            sendStr.SendData = Transmit(cmdData);
            Send(sendStr);

            // new thread to get read reply
            listenStart = true;
            //_thread = new Thread(ListenerServer);
            //_thread.Start();
            if (client.Client != null)
            {
                ReadProc(param.ProNum_Bcode.Trim());
            }

            //Writer(param.ProNum_Bcode.Trim());
            if (listenStart) { 
                return new StepResult { Data = param.ProNum_Bcode.Trim(), IsPassed = true };
            }
            else
            {
                return new StepResult { Data = "", IsPassed = true };
            }
        }

        public void Writer(string proNum_Bcode)
        {
            //connect

           /// Connect(ip, port);


            // prepare data
            int proNum_BcodeLength = proNum_Bcode.Length;


            if (proNum_BcodeLength > 64)
            {
                proNum_Bcode = proNum_Bcode.Substring(0, 64);
            }
            else
            {
                for (int j = 0; j < 64-proNum_BcodeLength; j++)
                {
                    proNum_Bcode += " ";
                }
            }

            int numOfBlock = 16;

            //if (proNum_BcodeLength % 4 != 0)
            //{
            //    numOfBlock = proNum_BcodeLength / 4 + 1;
            //    int numOfnul = 4 - proNum_BcodeLength % 4;
            //    string nul = "\0" + "\0" + "\0";
            //    proNum_Bcode = proNum_Bcode + nul;
            //    proNum_Bcode = proNum_Bcode.Substring(0, 4 * numOfBlock);
            //}
            //else
            //{
            //    numOfBlock = proNum_BcodeLength / 4;
            //}


            byte[] cmdData = new byte[4 + 4 * numOfBlock];

            cmdData[0] = 0x69; // 命令代码，写命令为69。
            cmdData[1] = 0x00; //Command Index。
            cmdData[2] = 0x00; //block number (start block)
            cmdData[3] = (byte)(numOfBlock-1); //number of blocks

            byte[] data;
            data = Encoding.ASCII.GetBytes(proNum_Bcode);

            data.CopyTo(cmdData, 4);


            //add crc
            sendStr2.SendData = Transmit(cmdData);

            // write
            // Send(sendStr);

            lock (sendStream)
            {
                Sending = true;
                byte[] comSendData = sendStr2.SendData;
                sendStream.Write(comSendData, 0, comSendData.Length);
                Sending = false;
            }

        }

        private byte[] Transmit(byte[] data)
        {


            int tempNum = data.Length + 3;
            int realNum = data.Length + 5;
            byte[] temp = new byte[tempNum];
            byte[] realdata = new byte[realNum];
            temp[0] = 0xAA;
            temp[1] = (byte)realNum;
            temp[2] = (byte)realNum;
            temp.CopyTo(realdata, 0);
            data.CopyTo(realdata, 3);
            byte[] crcdata = CRC(realdata.Take(tempNum).ToArray(), temp.Length);
            crcdata.CopyTo(realdata, realNum - 2);
            return realdata;
        }

        private static byte[] CRC(byte[] data, int len)
        {
            int crc = 0xFFFF;
            int poly = 0x8408;
            byte[] crcLH = new byte[2];
            for (int i = 0; i < len; i++)
            {
                crc = crc ^ (int)data[i];
                for (int j = 0; j < 8; j++)
                {
                    if ((crc & 0x0001) == 1)
                    {
                        crc = (crc >> 1) ^ poly;
                    }
                    else
                    {
                        crc = (crc >> 1);
                    }
                }
            }
            crc = ~crc;
            crcLH[0] = Convert.ToByte(crc & 0xff);
            crcLH[1] = Convert.ToByte((crc >> 8) & 0xff);
            return crcLH;
        }
        private void Send(SendStr sendSet)
        {
            if (Sending == true) return;//如果当前正在发送，则取消本次发送，本句注释后，可能阻塞在ComSend的lock处
            _ComSend = new Thread(new ParameterizedThreadStart(ComSend)); //new发送线程
            _ComSend.Start(sendSet);//发送线程启动
        }

        private void ComSend(object obj)
        {
            lock (this) //由于send()中的if(Sending == true) return，所以这里不会产生阻塞，如果没有那句，多次启动该线程，会在此处排队
            {
                if (client.Client!= null)
                {
                    try
                    {
                        while (sendStream.CanWrite)
                        {
                            lock (sendStream)
                            {
                                Sending = true;
                                SendStr temp = (SendStr)obj;
                                byte[] comSendData = temp.SendData;
                                sendStream.Write(comSendData, 0, comSendData.Length);
                                Sending = false;
                            }
                            Thread.Sleep(500);
                        }
                        //_ComSend.Abort();

                    }
                    catch (Exception err)
                    {
                        client.Close();
                       // MessageBox.Show("ComSend 命令发送失败：" + err.Message, "提示");
                    }
                }
            }
        }


        public void theout(object source, System.Timers.ElapsedEventArgs e)
        {
            listenStart = false;
            if (client.Connected)
            {
               //MessageBox.Show("该工步使用的读rfid插件已经超时10s！！！，发射器可能不在合理范围之内，结束工步", "提示");
            }
        }


        private void ReadProc(string proNum_Bcode)
        {
            //NetworkStream receiveStrem = client.GetStream();
            System.Timers.Timer t = new System.Timers.Timer(10000);//实例化Timer类，设置间隔时间为1000毫秒；

            t.Elapsed += new System.Timers.ElapsedEventHandler(theout);//到达时间的时候执行事件；

            t.AutoReset = false;//设置是执行一次（false）还是一直执行(true)；

            t.Enabled = true;//是否执行System.Timers.Timer.Elapsed事件；


            Thread.Sleep(30);
            while (listenStart)
            {
                try
                {
                    int readSize = 0;
                    byte[] buffer = new byte[3000];

                    while (sendStream.DataAvailable)
                    {
                        lock (sendStream)
                        {
                            readSize = sendStream.Read(buffer, 0, 3000);
                            //Console.WriteLine(readSize);

                        }

                        //string Text1 = string.Empty;
                        //for (int i = 0; i < 100; i++)
                        //{
                        //    Text1 += "0x" + buffer[i].ToString("X02") + " ";
                        //}

                        ////MessageBox.Show("收到字节：" + Text1);
                        //Console.WriteLine("收到字节1：" + Text1);

                        while (true)
                        {
                            if (buffer[0] == 0xAA && buffer[3] == 0x70 && buffer[1] == 0x14)
                            {

                                //byte[] a = buffer.Skip(5).Take(64).ToArray();
                                //val = Encoding.ASCII.GetString(a, 0, 64).Trim();


                                Writer(proNum_Bcode);
                                client.Close();
                                Console.WriteLine("写Rfid:"+ proNum_Bcode);
                                return;
                            }
                            else if (buffer[0] == 0xAA && buffer[3] == 0x70 && buffer[1] == 0x07)
                            {
                                buffer = buffer.Skip(7).ToArray();
                                //Console.WriteLine("收到字节2：" + string.Join(",", buffer));

                            }
                            else
                            {

                                //Console.WriteLine("收到字节3：" + string.Join(",", buffer));
                                break;
                            }
                            //Console.WriteLine("收到字节4：" + string.Join(",", buffer))；
                        }
                        break;

                    }


                }
                catch (Exception err)
                {
                    client.Close();

                  //  MessageBox.Show("ReadProc 出现错误：" + err.Message, "提示");
                    return;
                }
                //将缓存中的数据写入传输流
            }



            client.Close();
            return;
        }


        private void Connect(string ipAdress, string port)
        {
            IPAddress ip = IPAddress.Parse(ipAdress);

            client = new TcpClient();

            if (client.Connected)
            {
                return;
            }

            try
            {
                client.Connect(ip, int.Parse(port));
                sendStream = client.GetStream();
                //listenStart = true;
                //_thread = new Thread(ListenerServer);
                //_thread.Start();
            }
            catch (Exception err)
            {
                client.Close();
               // MessageBox.Show("Connect 出现错误：" + err.Message, "提示");
            }

        }



        public void WriterTo(string ipAdress, string port,string proNum_Bcode)
        {

            Connect(ipAdress, port);
            // reader request
            byte[] cmdData = new byte[2];
            cmdData[0] = 0x70;
            cmdData[1] = 0x00;
            sendStr.SendData = Transmit(cmdData);
            Send(sendStr);

            // new thread to get read reply
            listenStart = true;
            //_thread = new Thread(ListenerServer);
            //_thread.Start();
            if (client.Client != null)
            {
                ReadProc(proNum_Bcode);
            }

            if (listenStart)
            {
                Console.WriteLine("Sucess");
            }
            else
            {
                Console.WriteLine("Fail");
            }


        }

    }
}

