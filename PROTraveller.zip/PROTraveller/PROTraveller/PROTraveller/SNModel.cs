﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROTraveller
{
    public class SNModel
    {
        public int Pro_Id;
        public string SN;
        public string Status;
        public string LatestModifyTime;
        public string OrderNumber;
        public string Model;
        public string Line;
        public string Description;
        public string JobNumber;
        public int Reserved4;
        public string Reserved3;
    }
}
